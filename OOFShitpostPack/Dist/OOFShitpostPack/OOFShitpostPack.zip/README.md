### OOF Shitpost Pack

I made this for friends but I bet you might get a laugh too.